package com.example.cybooks.controllers;

import com.example.cybooks.models.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BookResultsController {
    @FXML
    private TableView<Book> tableView;
    @FXML
    private TableColumn<Book, String> titleCol;
    @FXML
    private TableColumn<Book, String> authorCol;
    @FXML
    private TableColumn<Book, String> publisherCol;

    @FXML
    public void initialize() {
        titleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        authorCol.setCellValueFactory(new PropertyValueFactory<>("Author"));
        publisherCol.setCellValueFactory(new PropertyValueFactory<>("Publisher"));
    }

    public void displaySearchResults(List<Map<String, String>> searchResults) {
        List<Book> books = searchResults.stream()
                .map(result -> new Book(result.get("Title"), result.get("Author"), result.get("Publisher")))
                .collect(Collectors.toList());

        ObservableList<Book> data = FXCollections.observableArrayList(books);
        tableView.setItems(data);
    }
}
